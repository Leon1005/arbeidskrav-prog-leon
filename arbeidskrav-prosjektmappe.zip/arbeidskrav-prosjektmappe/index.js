let output = document.getElementById("output-div");
let lifeBar = document.getElementById("life-bar");
let character = document.getElementById("warrior");
let materialInfo = document.getElementById("material-info");
let metalMine = document.getElementById("metal-mine");
let treverk = 0;
let metall = 0;
let bygninger = 0;
let styrke = 10;
let hp = 300;
let gotSword = false;
let combat = false;
let tree1 = document.getElementById("tree-1");
let tree2 = document.getElementById("tree-2");
let tree3 = document.getElementById("tree-3");
let buildingOutput = document.getElementById("building-div");
let buySmallBuildingBtn = document.getElementById("buy-building-1-btn");
let buyBigBuildingBtn = document.getElementById("buy-building-2-btn");
let monsterZone = document.getElementById("monster-div");

function updateMaterials() {
  materialInfo.innerHTML = `Treverk: ${treverk} enheter. Metall: ${metall} enheter. Antall bygninger:${bygninger}. Styrke: ${styrke}`;
}
function updateHp() {
  lifeBar.innerHTML = `${hp}hp`;
}

function buySmallBuilding() {
  if (metall >= 10 && treverk >= 50) {
    metall = metall - 10;
    treverk = treverk - 50;
    bygninger++;
    buildingOutput.innerHTML += `<img src="images/building-1.png">`;
  } else {
    alert("du mangler tilstrekkelig med ressurser!");
  }
  updateMaterials();
}

function buyBigBuilding() {
  if (metall >= 30 && treverk >= 150) {
    metall = metall - 30;
    treverk = treverk - 150;
    bygninger++;
    buildingOutput.innerHTML += `<img src="images/building-3.png">`;
  } else {
    alert("du mangler tilstrekkelig med ressurser!");
  }
  updateMaterials();
}
function buySword() {
  if (metall >= 200) {
    metall = metall - 200;
    gotSword = true;
  } else {
    alert("du mangler tilstrekkelig med ressurser!");
  }
}
var mCounter1 = 0;
var mCounter2 = 0;
var mCounter3 = 0;
function clash() {
  var monster1 = document.getElementById("monster-0");
  var monster2 = document.getElementById("monster-1");
  var monster3 = document.getElementById("monster-2");
  if (this.id === "monster-0") {
    if (mCounter1 < 3) {
      hp = hp - 15;
      mCounter1++;
    } else if (mCounter1 === 3) {
      monster1.style.display = "none";
      hp = hp - 15;
    }
  } else if (this.id === "monster-1") {
    if (mCounter2 < 3) {
      hp = hp - 15;
      mCounter2++;
    } else if (mCounter2 === 3) {
      monster2.style.display = "none";
      hp = hp - 15;
    }
  } else if (this.id === "monster-2") {
    if (mCounter3 < 3) {
      hp = hp - 15;
      mCounter3++;
    } else if (mCounter3 === 3) {
      monster3.style.display = "none";
      hp = hp - 15;
    }
  }
  updateHp();
}

function collectMetal() {
  if (combat === false) {
    warrior.style.left = "180px";
    warrior.style.transform = "scaleX(-1)";
    var encounterChance = Math.floor(Math.random() * 10);
    metall = metall + 10;
    console.log(encounterChance);
    updateMaterials();
    if (encounterChance === 9) {
      combat = true;
      warrior.style.left = "520px";
      warrior.style.transform = "scaleX(1)";
      let numberOfMonsters = Math.floor(Math.random() * 3 + 1);
      for (i = 0; i < numberOfMonsters; i++) {
        monsterZone.innerHTML += `<div id="monster-${i}"><img src="images/cute-wolfman.png"></div>`;
      }
      var monster1 = document.getElementById("monster-0");
      var monster2 = document.getElementById("monster-1");
      var monster3 = document.getElementById("monster-2");
      monster1.onclick = clash;
      monster2.onclick = clash;
      monster3.onclick = clash;
    }
  } else if (combat === true) {
    alert("du er i combat");
  }
}

let counterTree1 = 0;
let counterTree2 = 0;
let counterTree3 = 0;
function collectWood() {
  if (combat === false) {
    warrior.style.left = "900px";
    warrior.style.transform = "scaleX(1)";

    if (this.id === "tree-1") {
      if (counterTree1 < 9) {
        treverk = treverk + 25;
        counterTree1++;
      } else if (counterTree1 === 9) {
        tree1.style.display = "none";
        treverk = treverk + 25;
      }
    } else if (this.id === "tree-2") {
      if (counterTree2 < 9) {
        treverk = treverk + 25;
        counterTree2++;
      } else if (counterTree2 === 9) {
        tree2.style.display = "none";
        treverk = treverk + 25;
      }
    } else if (this.id === "tree-3") {
      if (counterTree3 < 9) {
        treverk = treverk + 25;
        counterTree3++;
      } else if (counterTree3 === 9) {
        tree3.style.display = "none";
        treverk = treverk + 25;
      }
    }
    updateMaterials();
  } else if (combat === true) {
    alert("du er i combat");
  }
}
tree1.onclick = collectWood;
tree2.onclick = collectWood;
tree3.onclick = collectWood;

buySmallBuildingBtn.onclick = buySmallBuilding;
buyBigBuildingBtn.onclick = buyBigBuilding;
